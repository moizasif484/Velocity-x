/* ============================================================
   Velocity X — racingGame.js
   Full 3D WebGL Car Racing Game Engine powered by Three.js
   ============================================================ */

import * as THREE from 'three';

export class RacingGame {
  constructor(options = {}) {
    this.canvas = options.canvas || document.getElementById('racing-canvas');
    if (!this.canvas) return;

    this.container = this.canvas.parentElement;

    // Game state
    this.isStarted = false;
    this.isFinished = false;
    this.startTime = 0;
    this.elapsedTime = 0;
    this.lap = 1;
    this.totalLaps = 3;
    this.nextCheckpointIndex = 1; // 0=Start, 1=CP1, 2=CP2, 3=CP3
    this.checkpointPassed = [true, false, false, false];

    // Controls
    this.keys = {
      up: false,
      down: false,
      left: false,
      right: false,
      space: false,
    };

    // Car Physics
    this.speed = 0; // in units/sec
    this.maxSpeed = 55.0; // ~160 KM/H
    this.maxReverseSpeed = -18.0;
    this.acceleration = 28.0;
    this.braking = 36.0;
    this.friction = 12.0;
    this.steeringAngle = 0;
    this.maxSteerAngle = 0.55; // radians
    this.steerSpeed = 2.8;
    this.carHeading = 0; // radians
    this.carPosition = new THREE.Vector3();

    // Wheel rotation
    this.wheelRotation = 0;

    // Track definition
    this.trackWidth = 22.0;
    this.trackCurve = null;

    this.animationFrameId = null;
    this.lastFrameTime = performance.now();

    this.init();
  }

  init() {
    this.setupScene();
    this.setupTrack();
    this.setupEnvironment();
    this.setupCar();
    this.setupCamera();
    this.setupEvents();

    this.resetRace();
    this.animate();
  }

  setupScene() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x05070e);
    this.scene.fog = new THREE.FogExp2(0x05070e, 0.005);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xddeeff, 0.6);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x22d3ff, 1.2);
    dirLight.position.set(100, 150, 50);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 400;
    const d = 150;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    this.scene.add(dirLight);

    // Secondary accent light (magenta)
    const accentLight = new THREE.DirectionalLight(0xff2f5e, 0.8);
    accentLight.position.set(-100, 80, -100);
    this.scene.add(accentLight);
  }

  setupTrack() {
    // Closed 3D Circuit Curve
    const points = [
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(120, 0, 40),
      new THREE.Vector3(240, 0, 160),
      new THREE.Vector3(260, 0, 320),
      new THREE.Vector3(140, 0, 420),
      new THREE.Vector3(-40, 0, 380),
      new THREE.Vector3(-180, 0, 260),
      new THREE.Vector3(-220, 0, 120),
      new THREE.Vector3(-120, 0, -20),
    ];

    this.trackCurve = new THREE.CatmullRomCurve3(points, true, 'centripetal');

    // Create Road Geometry
    const samples = 400;
    const trackPoints = this.trackCurve.getSpacedPoints(samples);
    const geometry = new THREE.BufferGeometry();
    const vertices = [];
    const uvs = [];
    const indices = [];

    const halfWidth = this.trackWidth / 2;

    for (let i = 0; i <= samples; i++) {
      const t = i / samples;
      const point = this.trackCurve.getPointAt(t);
      const tangent = this.trackCurve.getTangentAt(t);
      const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();

      const left = point.clone().add(normal.clone().multiplyScalar(halfWidth));
      const right = point.clone().add(normal.clone().multiplyScalar(-halfWidth));

      vertices.push(left.x, left.y + 0.05, left.z);
      vertices.push(right.x, right.y + 0.05, right.z);

      uvs.push(0, i * 2);
      uvs.push(1, i * 2);

      if (i < samples) {
        const row = i * 2;
        indices.push(row, row + 1, row + 2);
        indices.push(row + 1, row + 3, row + 2);
      }
    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    geometry.setIndex(indices);
    geometry.computeVertexNormals();

    const roadMaterial = new THREE.MeshStandardMaterial({
      color: 0x141824,
      roughness: 0.7,
      metalness: 0.2,
      side: THREE.DoubleSide,
    });

    const roadMesh = new THREE.Mesh(geometry, roadMaterial);
    roadMesh.receiveShadow = true;
    this.scene.add(roadMesh);

    // Glowing Neon Curbs (Inner & Outer)
    this.createNeonCurbs(samples, halfWidth);

    // Setup Checkpoints (4 Checkpoints evenly spaced)
    this.checkpoints = [
      { index: 0, t: 0.0, name: 'Finish / Start', pos: this.trackCurve.getPointAt(0.0) },
      { index: 1, t: 0.25, name: 'Checkpoint 1', pos: this.trackCurve.getPointAt(0.25) },
      { index: 2, t: 0.5, name: 'Checkpoint 2', pos: this.trackCurve.getPointAt(0.5) },
      { index: 3, t: 0.75, name: 'Checkpoint 3', pos: this.trackCurve.getPointAt(0.75) },
    ];

    // Build Checkpoint Arches
    this.checkpoints.forEach((cp, idx) => {
      this.createCheckpointArch(cp, idx === 0);
    });
  }

  createNeonCurbs(samples, halfWidth) {
    const innerPoints = [];
    const outerPoints = [];

    for (let i = 0; i <= samples; i++) {
      const t = i / samples;
      const point = this.trackCurve.getPointAt(t);
      const tangent = this.trackCurve.getTangentAt(t);
      const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();

      innerPoints.push(point.clone().add(normal.clone().multiplyScalar(halfWidth + 0.3)));
      outerPoints.push(point.clone().add(normal.clone().multiplyScalar(-halfWidth - 0.3)));
    }

    const innerCurve = new THREE.CatmullRomCurve3(innerPoints, true);
    const outerCurve = new THREE.CatmullRomCurve3(outerPoints, true);

    const innerGeo = new THREE.TubeGeometry(innerCurve, 300, 0.4, 8, true);
    const outerGeo = new THREE.TubeGeometry(outerCurve, 300, 0.4, 8, true);

    const cyanMat = new THREE.MeshBasicMaterial({ color: 0x22d3ff });
    const magentaMat = new THREE.MeshBasicMaterial({ color: 0xff2f5e });

    const innerMesh = new THREE.Mesh(innerGeo, cyanMat);
    const outerMesh = new THREE.Mesh(outerGeo, magentaMat);

    this.scene.add(innerMesh);
    this.scene.add(outerMesh);
  }

  createCheckpointArch(cp, isStartFinish) {
    const point = cp.pos;
    const tangent = this.trackCurve.getTangentAt(cp.t);
    const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();

    const archGroup = new THREE.Group();
    archGroup.position.copy(point);
    archGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), tangent);

    const width = this.trackWidth + 4;
    const height = 12;

    // Pillar Geometry
    const pillarGeo = new THREE.BoxGeometry(1.5, height, 1.5);
    const pillarMat = new THREE.MeshStandardMaterial({ color: 0x1f293d, metalness: 0.8, roughness: 0.2 });

    const leftPillar = new THREE.Mesh(pillarGeo, pillarMat);
    leftPillar.position.set(-width / 2, height / 2, 0);

    const rightPillar = new THREE.Mesh(pillarGeo, pillarMat);
    rightPillar.position.set(width / 2, height / 2, 0);

    // Crossbar
    const crossGeo = new THREE.BoxGeometry(width + 2, 2.2, 2);
    const neonColor = isStartFinish ? 0xff2f5e : 0x22d3ff;
    const crossMat = new THREE.MeshBasicMaterial({ color: neonColor });
    const crossbar = new THREE.Mesh(crossGeo, crossMat);
    crossbar.position.set(0, height, 0);

    archGroup.add(leftPillar);
    archGroup.add(rightPillar);
    archGroup.add(crossbar);

    this.scene.add(archGroup);
  }

  setupEnvironment() {
    // Infinite Ground
    const groundGeo = new THREE.PlaneGeometry(1600, 1600);
    const groundMat = new THREE.MeshStandardMaterial({ color: 0x070913, roughness: 0.9 });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.1;
    ground.receiveShadow = true;
    this.scene.add(ground);

    // Roadside 3D Trees & Neon Skyscrapers
    this.trees = [];
    const treeGeo = new THREE.ConeGeometry(3.5, 12, 6);
    const treeTrunkGeo = new THREE.CylinderGeometry(0.8, 1.0, 4, 6);

    const leafMat = new THREE.MeshStandardMaterial({ color: 0x0f2d3a, roughness: 0.8 });
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x1a120c });

    const buildingGeo = new THREE.BoxGeometry(1, 1, 1);
    const buildingMat = new THREE.MeshStandardMaterial({ color: 0x0d111e, metalness: 0.5, roughness: 0.4 });

    // Place trees and buildings along the outer perimeter
    const numProps = 120;
    for (let i = 0; i < numProps; i++) {
      const t = i / numProps;
      const point = this.trackCurve.getPointAt(t);
      const tangent = this.trackCurve.getTangentAt(t);
      const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();

      // Alternate left and right sides outside track
      const side = (i % 2 === 0 ? 1 : -1);
      const offsetDist = this.trackWidth / 2 + 10 + Math.random() * 25;
      const propPos = point.clone().add(normal.clone().multiplyScalar(side * offsetDist));

      if (i % 3 === 0) {
        // Neon Building
        const building = new THREE.Mesh(buildingGeo, buildingMat);
        const bWidth = 15 + Math.random() * 25;
        const bHeight = 40 + Math.random() * 90;
        const bDepth = 15 + Math.random() * 25;

        building.scale.set(bWidth, bHeight, bDepth);
        building.position.set(propPos.x, bHeight / 2, propPos.z);
        building.castShadow = true;
        this.scene.add(building);
      } else {
        // 3D Tree
        const treeGroup = new THREE.Group();
        const trunk = new THREE.Mesh(treeTrunkGeo, trunkMat);
        trunk.position.y = 2;
        const leaves = new THREE.Mesh(treeGeo, leafMat);
        leaves.position.y = 8;
        leaves.castShadow = true;

        treeGroup.add(trunk);
        treeGroup.add(leaves);
        treeGroup.position.copy(propPos);
        this.scene.add(treeGroup);
        this.trees.push(propPos);
      }
    }
  }

  setupCar() {
    this.carGroup = new THREE.Group();

    // Body Chassis
    const bodyGeo = new THREE.BoxGeometry(2.4, 1.1, 5.0);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0xe10600,
      metalness: 0.9,
      roughness: 0.15,
    });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = 0.8;
    body.castShadow = true;
    this.carGroup.add(body);

    // Cabin Cockpit
    const cabinGeo = new THREE.BoxGeometry(2.0, 0.85, 2.6);
    const cabinMat = new THREE.MeshStandardMaterial({
      color: 0x05060b,
      metalness: 0.95,
      roughness: 0.05,
    });
    const cabin = new THREE.Mesh(cabinGeo, cabinMat);
    cabin.position.set(0, 1.6, -0.2);
    this.carGroup.add(cabin);

    // Spoiler Wing
    const spoilerGeo = new THREE.BoxGeometry(2.6, 0.15, 0.6);
    const spoilerMat = new THREE.MeshStandardMaterial({ color: 0x111625 });
    const spoiler = new THREE.Mesh(spoilerGeo, spoilerMat);
    spoiler.position.set(0, 1.7, -2.3);

    const postGeo = new THREE.BoxGeometry(0.15, 0.6, 0.2);
    const postL = new THREE.Mesh(postGeo, spoilerMat);
    postL.position.set(-0.8, 1.3, -2.3);
    const postR = new THREE.Mesh(postGeo, spoilerMat);
    postR.position.set(0.8, 1.3, -2.3);

    this.carGroup.add(spoiler);
    this.carGroup.add(postL);
    this.carGroup.add(postR);

    // Wheels (4)
    const wheelGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.4, 18);
    wheelGeo.rotateZ(Math.PI / 2);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x151821, roughness: 0.8 });

    this.wheels = {
      fl: new THREE.Mesh(wheelGeo, wheelMat),
      fr: new THREE.Mesh(wheelGeo, wheelMat),
      rl: new THREE.Mesh(wheelGeo, wheelMat),
      rr: new THREE.Mesh(wheelGeo, wheelMat),
    };

    this.wheels.fl.position.set(-1.3, 0.5, 1.6);
    this.wheels.fr.position.set(1.3, 0.5, 1.6);
    this.wheels.rl.position.set(-1.3, 0.5, -1.6);
    this.wheels.rr.position.set(1.3, 0.5, -1.6);

    Object.values(this.wheels).forEach((w) => {
      w.castShadow = true;
      this.carGroup.add(w);
    });

    // Headlights
    const lightGeo = new THREE.BoxGeometry(0.6, 0.2, 0.1);
    const lightMat = new THREE.MeshBasicMaterial({ color: 0x22d3ff });
    const hlLeft = new THREE.Mesh(lightGeo, lightMat);
    hlLeft.position.set(-0.8, 0.8, 2.51);
    const hlRight = new THREE.Mesh(lightGeo, lightMat);
    hlRight.position.set(0.8, 0.8, 2.51);

    this.carGroup.add(hlLeft);
    this.carGroup.add(hlRight);

    // Taillights
    const tailMat = new THREE.MeshBasicMaterial({ color: 0xff2f5e });
    const tlLeft = new THREE.Mesh(lightGeo, tailMat);
    tlLeft.position.set(-0.8, 0.8, -2.51);
    const tlRight = new THREE.Mesh(lightGeo, tailMat);
    tlRight.position.set(0.8, 0.8, -2.51);

    this.carGroup.add(tlLeft);
    this.carGroup.add(tlRight);

    // Neon Underglow
    const underglowLight = new THREE.PointLight(0x22d3ff, 3, 12);
    underglowLight.position.set(0, 0.2, 0);
    this.carGroup.add(underglowLight);

    this.scene.add(this.carGroup);
  }

  setupCamera() {
    this.camera = new THREE.PerspectiveCamera(
      60,
      this.container.clientWidth / this.container.clientHeight,
      0.1,
      1000
    );
  }

  setupEvents() {
    // Keyboard Controls
    this.onKeyDown = (e) => {
      const code = e.code;
      if (code === 'KeyW' || code === 'ArrowUp') this.keys.up = true;
      if (code === 'KeyS' || code === 'ArrowDown') this.keys.down = true;
      if (code === 'KeyA' || code === 'ArrowLeft') this.keys.left = true;
      if (code === 'KeyD' || code === 'ArrowRight') this.keys.right = true;
      if (code === 'Space') this.keys.space = true;
      if (code === 'KeyR') this.resetRace();
    };

    this.onKeyUp = (e) => {
      const code = e.code;
      if (code === 'KeyW' || code === 'ArrowUp') this.keys.up = false;
      if (code === 'KeyS' || code === 'ArrowDown') this.keys.down = false;
      if (code === 'KeyA' || code === 'ArrowLeft') this.keys.left = false;
      if (code === 'KeyD' || code === 'ArrowRight') this.keys.right = false;
      if (code === 'Space') this.keys.space = false;
    };

    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);

    // Window Resize
    this.onResize = () => {
      if (!this.container) return;
      const w = this.container.clientWidth;
      const h = this.container.clientHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    };

    window.addEventListener('resize', this.onResize);

    // UI Buttons
    document.getElementById('btn-start-race')?.addEventListener('click', () => this.startRace());
    document.getElementById('btn-restart-race')?.addEventListener('click', () => this.resetRace());
    document.getElementById('btn-manual-restart')?.addEventListener('click', () => this.resetRace());
  }

  startRace() {
    this.isStarted = true;
    this.startTime = performance.now();
    document.getElementById('racing-start-overlay')?.classList.add('is-hidden');
    document.getElementById('racing-finish-overlay')?.classList.add('is-hidden');
  }

  resetRace() {
    this.isStarted = false;
    this.isFinished = false;
    this.elapsedTime = 0;
    this.lap = 1;
    this.nextCheckpointIndex = 1;
    this.checkpointPassed = [true, false, false, false];

    // Position Car at Start Line (Point 0 on track curve)
    const startPoint = this.trackCurve.getPointAt(0);
    const tangent = this.trackCurve.getTangentAt(0);

    this.carPosition.copy(startPoint);
    this.carHeading = Math.atan2(tangent.x, tangent.z);
    this.speed = 0;
    this.steeringAngle = 0;

    this.carGroup.position.copy(this.carPosition);
    this.carGroup.rotation.y = this.carHeading;

    document.getElementById('racing-start-overlay')?.classList.remove('is-hidden');
    document.getElementById('racing-finish-overlay')?.classList.add('is-hidden');

    this.updateHUD();
  }

  updatePhysics(dt) {
    if (!this.isStarted || this.isFinished) return;

    // Timer update
    this.elapsedTime = (performance.now() - this.startTime) / 1000;

    // Acceleration & Braking
    if (this.keys.up) {
      this.speed += this.acceleration * dt;
    } else if (this.keys.down) {
      this.speed -= this.braking * dt;
    } else {
      // Coasting friction
      if (this.speed > 0) {
        this.speed = Math.max(0, this.speed - this.friction * dt);
      } else if (this.speed < 0) {
        this.speed = Math.min(0, this.speed + this.friction * dt);
      }
    }

    // Handbrake
    if (this.keys.space) {
      this.speed *= 0.93;
    }

    // Speed limits
    this.speed = THREE.MathUtils.clamp(this.speed, this.maxReverseSpeed, this.maxSpeed);

    // Steering logic
    let targetSteer = 0;
    if (this.keys.left) targetSteer += this.maxSteerAngle;
    if (this.keys.right) targetSteer -= this.maxSteerAngle;

    this.steeringAngle = THREE.MathUtils.lerp(this.steeringAngle, targetSteer, this.steerSpeed * dt);

    // Turn car based on current speed
    const speedRatio = Math.abs(this.speed) / this.maxSpeed;
    if (Math.abs(this.speed) > 0.5) {
      const turnDir = this.speed >= 0 ? 1 : -1;
      this.carHeading += this.steeringAngle * turnDir * (0.8 + speedRatio * 0.4) * dt;
    }

    // Apply movement
    const moveVector = new THREE.Vector3(
      Math.sin(this.carHeading),
      0,
      Math.cos(this.carHeading)
    ).multiplyScalar(this.speed * dt);

    this.carPosition.add(moveVector);
    this.carGroup.position.copy(this.carPosition);
    this.carGroup.rotation.y = this.carHeading;

    // Front wheel visual turning & rotation
    this.wheelRotation += (this.speed * dt) / 0.5;
    this.wheels.fl.rotation.x = this.wheelRotation;
    this.wheels.fr.rotation.x = this.wheelRotation;
    this.wheels.rl.rotation.x = this.wheelRotation;
    this.wheels.rr.rotation.x = this.wheelRotation;

    this.wheels.fl.rotation.y = this.steeringAngle;
    this.wheels.fr.rotation.y = this.steeringAngle;

    // Collision Check against Track Boundaries
    this.checkCollisions();

    // Checkpoint & Lap Check
    this.checkCheckpoints();
  }

  checkCollisions() {
    // Find closest point on track curve
    const numSamples = 100;
    let minDist = Infinity;
    let closestPoint = null;

    for (let i = 0; i < numSamples; i++) {
      const t = i / numSamples;
      const pt = this.trackCurve.getPointAt(t);
      const dist = this.carPosition.distanceTo(pt);
      if (dist < minDist) {
        minDist = dist;
        closestPoint = pt;
      }
    }

    const maxAllowedDist = this.trackWidth / 2 - 1.2;
    if (minDist > maxAllowedDist) {
      // Off track collision! Bounce car back towards track center
      const pushDir = closestPoint.clone().sub(this.carPosition).normalize();
      this.carPosition.add(pushDir.multiplyScalar(0.8));
      this.speed *= -0.3; // Dampen and bounce velocity
    }
  }

  checkCheckpoints() {
    const currentTargetCP = this.checkpoints[this.nextCheckpointIndex];
    const distToTarget = this.carPosition.distanceTo(currentTargetCP.pos);

    if (distToTarget < this.trackWidth + 4) {
      this.checkpointPassed[this.nextCheckpointIndex] = true;
      this.nextCheckpointIndex = (this.nextCheckpointIndex + 1) % this.checkpoints.length;

      // Completed a full lap when wrapping around to Checkpoint 1 (Index 1)
      if (this.nextCheckpointIndex === 1 && this.checkpointPassed[3]) {
        this.checkpointPassed = [true, false, false, false];
        if (this.lap < this.totalLaps) {
          this.lap++;
        } else {
          // Finished all 3 laps!
          this.isFinished = true;
          this.showFinishScreen();
        }
      }
    }
  }

  updateCamera() {
    // Third Person Chase Camera
    const forward = new THREE.Vector3(Math.sin(this.carHeading), 0, Math.cos(this.carHeading));
    const targetCamPos = this.carPosition
      .clone()
      .sub(forward.clone().multiplyScalar(15))
      .add(new THREE.Vector3(0, 6.5, 0));

    this.camera.position.lerp(targetCamPos, 0.12);

    const lookAtTarget = this.carPosition.clone().add(forward.clone().multiplyScalar(6)).add(new THREE.Vector3(0, 1.5, 0));
    this.camera.lookAt(lookAtTarget);
  }

  updateHUD() {
    const kmh = Math.max(0, Math.round(Math.abs(this.speed) * 3.6));
    const speedVal = document.getElementById('hud-speed-val');
    if (speedVal) speedVal.textContent = String(kmh);

    const speedFill = document.getElementById('hud-speed-fill');
    if (speedFill) {
      const pct = Math.min(100, (kmh / 180) * 100);
      speedFill.style.width = `${pct}%`;
    }

    const timerVal = document.getElementById('hud-timer-val');
    if (timerVal) {
      const mins = String(Math.floor(this.elapsedTime / 60)).padStart(2, '0');
      const secs = String(Math.floor(this.elapsedTime % 60)).padStart(2, '0');
      const ms = String(Math.floor((this.elapsedTime % 1) * 1000)).padStart(3, '0');
      timerVal.textContent = `${mins}:${secs}.${ms}`;
    }

    const lapVal = document.getElementById('hud-lap-val');
    if (lapVal) lapVal.textContent = `${this.lap} / ${this.totalLaps}`;

    const cpVal = document.getElementById('hud-cp-val');
    if (cpVal) cpVal.textContent = `${this.nextCheckpointIndex} / 4`;
  }

  showFinishScreen() {
    const finalTime = document.getElementById('final-race-time');
    const timerVal = document.getElementById('hud-timer-val');
    if (finalTime && timerVal) {
      finalTime.textContent = timerVal.textContent;
    }
    document.getElementById('racing-finish-overlay')?.classList.remove('is-hidden');
  }

  animate() {
    this.animationFrameId = requestAnimationFrame(() => this.animate());

    const now = performance.now();
    const dt = Math.min((now - this.lastFrameTime) / 1000, 0.1);
    this.lastFrameTime = now;

    this.updatePhysics(dt);
    this.updateCamera();
    this.updateHUD();

    this.renderer.render(this.scene, this.camera);
  }

  destroy() {
    if (this.animationFrameId) cancelAnimationFrame(this.animationFrameId);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
  }
}

export function initRacingGame() {
  const canvas = document.getElementById('racing-canvas');
  if (!canvas) return null;
  return new RacingGame({ canvas });
}

export default initRacingGame;
