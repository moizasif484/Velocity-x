/**
 * Velocity X — Gallery Module
 * Filterable gallery grid with an accessible lightbox.
 */

const SELECTORS = {
  root: '.gallery',
  filterBtn: '.gallery__filter-btn',
  item: '.gallery__item',
  image: 'img'
};

const CLASSES = {
  active: 'is-active',
  hidden: 'is-hidden',
  open: 'is-open'
};

let lightbox = null;
let lightboxImg = null;
let lightboxCaption = null;
let visibleItems = [];
let currentIndex = 0;
let lastFocused = null;

/**
 * Builds the lightbox markup once and appends it to the body.
 */
function buildLightbox() {
  if (lightbox) return;

  lightbox = document.createElement('div');
  lightbox.className = 'lightbox';
  lightbox.setAttribute('role', 'dialog');
  lightbox.setAttribute('aria-modal', 'true');
  lightbox.setAttribute('aria-hidden', 'true');
  lightbox.innerHTML = `
    <button class="lightbox__close" type="button" aria-label="Close gallery">&times;</button>
    <button class="lightbox__nav lightbox__nav--prev" type="button" aria-label="Previous image">&#8249;</button>
    <figure class="lightbox__figure">
      <img class="lightbox__image" src="" alt="">
      <figcaption class="lightbox__caption"></figcaption>
    </figure>
    <button class="lightbox__nav lightbox__nav--next" type="button" aria-label="Next image">&#8250;</button>
  `;

  document.body.appendChild(lightbox);

  lightboxImg = lightbox.querySelector('.lightbox__image');
  lightboxCaption = lightbox.querySelector('.lightbox__caption');

  lightbox.querySelector('.lightbox__close').addEventListener('click', closeLightbox);
  lightbox.querySelector('.lightbox__nav--prev').addEventListener('click', () => step(-1));
  lightbox.querySelector('.lightbox__nav--next').addEventListener('click', () => step(1));

  lightbox.addEventListener('click', (event) => {
    if (event.target === lightbox) closeLightbox();
  });
}

/**
 * Renders the image at the given index inside the lightbox.
 * @param {number} index
 */
function render(index) {
  const item = visibleItems[index];
  if (!item) return;

  const source = item.querySelector(SELECTORS.image);
  const full = item.dataset.full || (source && source.src) || '';
  const caption = item.dataset.caption || (source && source.alt) || '';

  currentIndex = index;
  lightboxImg.src = full;
  lightboxImg.alt = caption;
  lightboxCaption.textContent = caption;
}

/**
 * Moves the lightbox forward or backward, wrapping around the ends.
 * @param {number} direction
 */
function step(direction) {
  if (!visibleItems.length) return;
  const next = (currentIndex + direction + visibleItems.length) % visibleItems.length;
  render(next);
}

/**
 * Opens the lightbox on a given item.
 * @param {HTMLElement} item
 */
function openLightbox(item) {
  const index = visibleItems.indexOf(item);
  if (index === -1) return;

  lastFocused = document.activeElement;
  render(index);

  lightbox.classList.add(CLASSES.open);
  lightbox.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  lightbox.querySelector('.lightbox__close').focus();
}

function closeLightbox() {
  if (!lightbox) return;

  lightbox.classList.remove(CLASSES.open);
  lightbox.setAttribute('aria-hidden', 'true');
  lightboxImg.src = '';
  document.body.style.overflow = '';

  if (lastFocused) lastFocused.focus();
}

function onKeydown(event) {
  if (!lightbox || !lightbox.classList.contains(CLASSES.open)) return;

  if (event.key === 'Escape') closeLightbox();
  if (event.key === 'ArrowLeft') step(-1);
  if (event.key === 'ArrowRight') step(1);
}

/**
 * Applies a category filter to the grid.
 * @param {HTMLElement} root
 * @param {string} filter
 */
function applyFilter(root, filter) {
  const items = Array.from(root.querySelectorAll(SELECTORS.item));

  items.forEach((item) => {
    const category = item.dataset.category || 'all';
    const match = filter === 'all' || category === filter;
    item.classList.toggle(CLASSES.hidden, !match);
  });

  visibleItems = items.filter((item) => !item.classList.contains(CLASSES.hidden));
}

export function initGallery() {
  const root = document.querySelector(SELECTORS.root);
  if (!root) return;

  buildLightbox();
  applyFilter(root, 'all');

  root.addEventListener('click', (event) => {
    const filterBtn = event.target.closest(SELECTORS.filterBtn);
    if (filterBtn) {
      root.querySelectorAll(SELECTORS.filterBtn).forEach((btn) => {
        btn.classList.toggle(CLASSES.active, btn === filterBtn);
      });
      applyFilter(root, filterBtn.dataset.filter || 'all');
      return;
    }

    const item = event.target.closest(SELECTORS.item);
    if (item) {
      event.preventDefault();
      openLightbox(item);
    }
  });

  document.addEventListener('keydown', onKeydown);
}

export default initGallery;
