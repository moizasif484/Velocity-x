/* ============================================================
   Velocity X — auth.js
   Local Auth management (Nova ID Login & Sign Up)
   ============================================================ */

import { $, $$ } from './utils.js';
import { toast, openModal, closeModal } from './ui.js';

const SESSION_KEY = 'velocityX_user';
const USERS_KEY = 'velocityX_users';

const PATTERNS = {
  email: /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i,
};

// Registered Users Database (localStorage array)
export function getRegisteredUsers() {
  try {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveRegisteredUser(user) {
  const users = getRegisteredUsers();
  users.push(user);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

// Active User Session (localStorage object)
export function getCurrentUser() {
  try {
    const data = localStorage.getItem(SESSION_KEY);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function setCurrentUser(user) {
  if (!user) {
    localStorage.removeItem(SESSION_KEY);
  } else {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  }
  updateAuthUI();
}

export function updateAuthUI() {
  const wrap = $('#nav-auth-wrap');
  if (!wrap) return;

  const user = getCurrentUser();
  if (user) {
    const displayName = user.username || user.email.split('@')[0];
    const initial = displayName[0].toUpperCase();
    wrap.innerHTML = `
      <div class="user-pill" title="Logged in as ${displayName}">
        <span class="user-avatar">${initial}</span>
        <span class="user-name">${displayName}</span>
        <button class="btn-logout" id="btn-logout" title="Sign Out" type="button" aria-label="Sign Out">&times;</button>
      </div>
    `;
    $('#btn-logout', wrap)?.addEventListener('click', () => {
      setCurrentUser(null);
      toast('Signed out successfully.', { type: 'info' });
    });
  } else {
    wrap.innerHTML = `
      <button class="btn btn--ghost btn--sm nav__auth-btn" id="nav-login-btn" data-modal-open="modal-auth" data-auth-tab="login" data-ripple type="button">
        <span>Sign In</span>
      </button>
      <button class="btn btn--ghost btn--sm nav__auth-btn" id="nav-signup-btn" data-modal-open="modal-auth" data-auth-tab="signup" data-ripple type="button">
        <span>Sign Up</span>
      </button>
    `;
  }
}

function setError(fieldId, message) {
  const input = $('#' + fieldId);
  if (!input) return;
  const wrapper = input.closest('.field') || input.parentElement;
  let errHost = $('[data-err-for="' + fieldId + '"]', wrapper);
  if (!errHost) {
    errHost = document.createElement('small');
    errHost.className = 'field__err';
    errHost.dataset.errFor = fieldId;
    wrapper.appendChild(errHost);
  }
  errHost.textContent = message || '';
  wrapper?.classList.toggle('is-invalid', Boolean(message));
}

function clearErrors(form) {
  if (!form) return;
  $$('.field', form).forEach(field => field.classList.remove('is-invalid'));
  $$('.field__err', form).forEach(err => err.textContent = '');
}

export function switchAuthTab(mode) {
  const tabLogin = $('#tab-login');
  const tabSignup = $('#tab-signup');
  const formLogin = $('#auth-form-login');
  const formSignup = $('#auth-form-signup');

  const isLogin = mode === 'login';

  tabLogin?.classList.toggle('is-active', isLogin);
  tabSignup?.classList.toggle('is-active', !isLogin);
  formLogin?.classList.toggle('is-hidden', !isLogin);
  formSignup?.classList.toggle('is-hidden', isLogin);

  if (formLogin) clearErrors(formLogin);
  if (formSignup) clearErrors(formSignup);
}

export function initAuth() {
  updateAuthUI();

  const tabLogin = $('#tab-login');
  const tabSignup = $('#tab-signup');
  const formLogin = $('#auth-form-login');
  const formSignup = $('#auth-form-signup');

  tabLogin?.addEventListener('click', () => switchAuthTab('login'));
  tabSignup?.addEventListener('click', () => switchAuthTab('signup'));

  // Global listener for buttons/links triggering auth modal or switching tabs
  document.addEventListener('click', (e) => {
    const trigger = e.target.closest('[data-modal-open="modal-auth"], [data-auth-tab], [data-auth-switch]');
    if (!trigger) return;

    e.preventDefault();
    const targetTab = trigger.dataset.authTab || trigger.dataset.authSwitch || 'login';
    openModal('modal-auth', trigger);
    switchAuthTab(targetTab);
  });

  // Form submission: Sign In
  formLogin?.addEventListener('submit', (e) => {
    e.preventDefault();
    clearErrors(formLogin);

    const identity = $('#login-email')?.value.trim();
    const password = $('#login-password')?.value.trim();

    let hasError = false;
    if (!identity) {
      setError('login-email', 'Email or Username is required.');
      hasError = true;
    }
    if (!password) {
      setError('login-password', 'Password is required.');
      hasError = true;
    }

    if (hasError) return;

    // Check credentials against local user database
    const users = getRegisteredUsers();
    const foundUser = users.find(u =>
      (u.email.toLowerCase() === identity.toLowerCase() || u.username.toLowerCase() === identity.toLowerCase()) &&
      u.password === password
    );

    if (foundUser) {
      const sessionUser = { username: foundUser.username, email: foundUser.email, loggedInAt: new Date().toISOString() };
      setCurrentUser(sessionUser);
      closeModal('modal-auth');
      toast(`Welcome back, ${sessionUser.username}!`, { type: 'success' });
      formLogin.reset();
    } else if (users.length === 0) {
      // Fallback dev mode if no registered accounts exist yet
      const username = identity.includes('@') ? identity.split('@')[0] : identity;
      const sessionUser = { username, email: identity, loggedInAt: new Date().toISOString() };
      setCurrentUser(sessionUser);
      closeModal('modal-auth');
      toast(`Welcome back, ${sessionUser.username}!`, { type: 'success' });
      formLogin.reset();
    } else {
      setError('login-password', 'Invalid identity or password.');
      toast('Invalid credentials. Please check your details.', { type: 'error' });
    }
  });

  // Form submission: Sign Up (Create Account)
  formSignup?.addEventListener('submit', (e) => {
    e.preventDefault();
    clearErrors(formSignup);

    const username = $('#signup-username')?.value.trim();
    const email = $('#signup-email')?.value.trim();
    const password = $('#signup-password')?.value.trim();
    const confirmPassword = $('#signup-confirm-password')?.value.trim();

    let hasError = false;

    if (!username) {
      setError('signup-username', 'Driver handle / name is required.');
      hasError = true;
    } else if (username.length < 2) {
      setError('signup-username', 'Name must be at least 2 characters.');
      hasError = true;
    }

    if (!email) {
      setError('signup-email', 'Email address is required.');
      hasError = true;
    } else if (!PATTERNS.email.test(email)) {
      setError('signup-email', 'Enter a valid email address.');
      hasError = true;
    }

    if (!password) {
      setError('signup-password', 'Password is required.');
      hasError = true;
    } else if (password.length < 6) {
      setError('signup-password', 'Password must be at least 6 characters.');
      hasError = true;
    }

    if (!confirmPassword) {
      setError('signup-confirm-password', 'Please confirm your password.');
      hasError = true;
    } else if (password && password !== confirmPassword) {
      setError('signup-confirm-password', 'Passwords do not match.');
      hasError = true;
    }

    if (hasError) {
      toast('Please fix the highlighted errors.', { type: 'error' });
      return;
    }

    // Check if account already exists
    const users = getRegisteredUsers();
    const exists = users.some(u =>
      u.email.toLowerCase() === email.toLowerCase() ||
      u.username.toLowerCase() === username.toLowerCase()
    );

    if (exists) {
      setError('signup-email', 'An account with this email or handle already exists.');
      toast('An account with this email or handle already exists.', { type: 'error' });
      return;
    }

    // Register user
    const newUser = {
      username,
      email,
      password,
      createdAt: new Date().toISOString(),
    };

    saveRegisteredUser(newUser);

    // Set active session
    const sessionUser = { username, email, loggedInAt: new Date().toISOString() };
    setCurrentUser(sessionUser);

    closeModal('modal-auth');
    toast(`Account created! Welcome to Velocity X, ${username}.`, { type: 'success' });
    formSignup.reset();
  });
}

export default initAuth;
