/* ============================================================
   VELOCITY X — main.js
   Application bootstrapper.
   Strategy:
     1. Boot lightweight UI modules immediately (fast LCP).
     2. Defer the WebGL scene until the browser is idle so the
        hero text paints first — key for Lighthouse > 90.
     3. Never let a single module failure break the page.
   ============================================================ */

import { $, bus, deviceTier, prefersReducedMotion, whenIdle } from './modules/utils.js';
import { initPreloader }   from './modules/preloader.js';
import { initNav }         from './modules/nav.js';
import { initAnimations }  from './modules/animations.js';
import { initUI }          from './modules/ui.js';
import { initCars }        from './modules/cars.js';
import { initGallery }     from './modules/gallery.js';
import { initTrailer }     from './modules/trailer.js';
import { initLeaderboard } from './modules/leaderboard.js';
import { initContact }     from './modules/contact.js';
import { initAuth }        from './modules/auth.js';

/** Run a module without letting an error cascade. */
const safe = (name, fn) => {
  try { return fn(); }
  catch (err) { console.warn(`[VelocityX] ${name} failed:`, err); return null; }
};

const boot = async () => {
  const tier = deviceTier();
  document.documentElement.dataset.tier = tier.tier;
  document.documentElement.dataset.pointer = tier.hasHover ? 'fine' : 'coarse';

  const preloader = safe('preloader', initPreloader);

  /* ---- Instant, DOM-only modules ---------------------- */
  safe('nav',         initNav);
  safe('auth',        initAuth);
  safe('ui',          initUI);
  safe('animations',  initAnimations);
  safe('cars',        initCars);
  safe('gallery',     initGallery);
  safe('trailer',     initTrailer);
  safe('leaderboard', initLeaderboard);
  safe('contact',     initContact);

  /* Boot 3D Racing Arena */
  safe('racingGame', async () => {
    const { initRacingGame } = await import('./three/racingGame.js');
    initRacingGame();
  });

  preloader?.setProgress(0.35, 'Building interface');

  /* ---- Deferred WebGL --------------------------------- */
  const canvas = $('#hero-canvas');
  const skip3D = !canvas || prefersReducedMotion() || !tier.webgl;

  if (skip3D) {
    // Graceful fallback: the animated CSS hero background carries the section.
    canvas?.remove();
    document.querySelector('.hero__hint')?.remove();
    preloader?.setProgress(1, 'Ready');
    preloader?.done();
    return;
  }

  await whenIdle(); // yield to first paint

  try {
    const { HeroScene } = await import('./three/scene.js');

    const scene = new HeroScene({
      canvas,
      tier,
      onProgress: (p, label) => preloader?.setProgress(0.35 + p * 0.6, label)
    });

    await scene.init();

    // The car list broadcasts paint changes; repaint the 3D body live.
    bus.on('car:select', (car) => scene.setPaint(car.paint, car.accent));

    // Expose for debugging / future integrations.
    window.__velocityX = { scene, bus };

    canvas.classList.add('is-ready');
    preloader?.setProgress(1, 'Ready');
    preloader?.done();
  } catch (err) {
    console.warn('[VelocityX] 3D scene unavailable:', err);
    canvas.remove();
    preloader?.setProgress(1, 'Ready');
    preloader?.done();
  }
};

// DOM may already be parsed because the module script is deferred by default.
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot, { once: true });
} else {
  boot();
}
